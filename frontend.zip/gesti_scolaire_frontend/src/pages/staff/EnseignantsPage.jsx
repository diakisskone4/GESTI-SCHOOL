import { useState } from "react";
import { Plus } from "lucide-react";
import PageHeader from "../../components/ui/PageHeader";
import DataTable from "../../components/ui/DataTable";
import Modal from "../../components/ui/Modal";
import { useFetch } from "../../hooks/useFetch";
import { useAuth } from "../../context/AuthContext";
import { useToast, extractErrorMessage } from "../../context/ToastContext";
import { enseignantsApi, usersApi, matieresApi } from "../../api/endpoints";

const EMPTY_FORM = {
  email: "", first_name: "", last_name: "", nom: "", prenom: "", sexe: "F",
  grade_academique: "", matieres_enseignees: [],
};

export default function EnseignantsPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const etablissementId = user?.etablissement_courant;

  const { data, loading, reload } = useFetch(() => enseignantsApi.list({ etablissement: etablissementId }), [etablissementId]);
  const { data: matieres } = useFetch(() => matieresApi.list({ etablissement: etablissementId }), [etablissementId]);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const toggleMatiere = (id) => {
    setForm((f) => ({
      ...f,
      matieres_enseignees: f.matieres_enseignees.includes(id)
        ? f.matieres_enseignees.filter((m) => m !== id)
        : [...f.matieres_enseignees, id],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const newUser = await usersApi.create({
        email: form.email, first_name: form.first_name, last_name: form.last_name,
        role: "enseignant", etablissement_courant: etablissementId,
      });
      await enseignantsApi.create({
        user: newUser.id, etablissement: etablissementId, nom: form.nom, prenom: form.prenom,
        sexe: form.sexe, grade_academique: form.grade_academique,
        matieres_enseignees: form.matieres_enseignees,
      });
      notify("Enseignant créé. Un mot de passe temporaire a été généré côté serveur.", "success");
      setModalOpen(false);
      reload();
    } catch (err) {
      notify(extractErrorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Enseignants"
        subtitle="Corps enseignant de l'établissement"
        actions={
          <button onClick={() => { setForm(EMPTY_FORM); setModalOpen(true); }} className="btn-primary">
            <Plus size={16} /> Ajouter un enseignant
          </button>
        }
      />

      <DataTable
        loading={loading}
        rows={data?.results || []}
        columns={[
          { key: "matricule", header: "Matricule" },
          { key: "nom_complet", header: "Nom" },
          { key: "grade_academique", header: "Grade" },
          { key: "matieres_enseignees_noms", header: "Matières", render: (r) => (r.matieres_enseignees_noms || []).join(", ") || "—" },
        ]}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Ajouter un enseignant"
        width="max-w-2xl"
        footer={
          <>
            <button className="btn-secondary" onClick={() => setModalOpen(false)}>Annuler</button>
            <button className="btn-primary" disabled={saving} form="ens-form">Enregistrer</button>
          </>
        }
      >
        <form id="ens-form" onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="label">Nom</label>
            <input required className="input" value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value, last_name: e.target.value })} />
          </div>
          <div>
            <label className="label">Prénom</label>
            <input required className="input" value={form.prenom} onChange={(e) => setForm({ ...form, prenom: e.target.value, first_name: e.target.value })} />
          </div>
          <div className="sm:col-span-2">
            <label className="label">Email (identifiant de connexion)</label>
            <input required type="email" className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="label">Sexe</label>
            <select className="input" value={form.sexe} onChange={(e) => setForm({ ...form, sexe: e.target.value })}>
              <option value="F">Féminin</option>
              <option value="M">Masculin</option>
            </select>
          </div>
          <div>
            <label className="label">Grade académique</label>
            <input className="input" value={form.grade_academique} onChange={(e) => setForm({ ...form, grade_academique: e.target.value })} />
          </div>
          <div className="sm:col-span-2">
            <label className="label">Matières enseignées</label>
            <div className="flex flex-wrap gap-2">
              {(matieres?.results || []).map((m) => (
                <button
                  type="button"
                  key={m.id}
                  onClick={() => toggleMatiere(m.id)}
                  className={`badge border ${
                    form.matieres_enseignees.includes(m.id)
                      ? "border-brand-300 bg-brand-50 text-brand-700"
                      : "border-slate-200 text-slate-500"
                  }`}
                >
                  {m.nom}
                </button>
              ))}
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
}
