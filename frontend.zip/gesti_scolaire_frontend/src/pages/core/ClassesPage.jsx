import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useFetch } from "../../hooks/useFetch";
import CrudPage from "../../components/ui/CrudPage";
import PageHeader from "../../components/ui/PageHeader";
import { classesApi, niveauxApi, anneesScolairesApi, matieresApi } from "../../api/endpoints";

const TABS = [
  { key: "classes", label: "Classes" },
  { key: "niveaux", label: "Niveaux" },
  { key: "matieres", label: "Matières" },
];

export default function ClassesPage() {
  const { user } = useAuth();
  const etablissementId = user?.etablissement_courant;
  const [tab, setTab] = useState("classes");

  const { data: niveaux } = useFetch(() => niveauxApi.list({ etablissement: etablissementId }), [etablissementId]);
  const { data: annees } = useFetch(() => anneesScolairesApi.list({ etablissement: etablissementId }), [etablissementId]);

  const niveauOptions = (niveaux?.results || []).map((n) => ({ value: n.id, label: n.nom }));
  const anneeOptions = (annees?.results || []).map((a) => ({ value: a.id, label: a.libelle }));

  return (
    <div>
      <PageHeader title="Classes & organisation" subtitle="Niveaux, matières et classes de l'établissement" />

      <div className="mb-5 inline-flex rounded-xl bg-slate-100 p-1">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
              tab === t.key ? "bg-white text-brand-600 shadow-sm" : "text-slate-500"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "classes" && (
        <CrudPage
          title=""
          apiResource={classesApi}
          filters={{ etablissement: etablissementId }}
          fields={[
            { name: "nom", label: "Nom de la classe (ex: 6e A)", required: true },
            { name: "niveau", label: "Niveau", type: "select", options: niveauOptions, required: true },
            { name: "annee_scolaire", label: "Année scolaire", type: "select", options: anneeOptions, required: true },
            { name: "effectif_max", label: "Effectif maximum", type: "number" },
            { name: "salle", label: "Salle" },
          ]}
          columns={[
            { key: "nom", header: "Classe" },
            { key: "niveau_nom", header: "Niveau" },
            { key: "effectif_actuel", header: "Effectif" },
            { key: "salle", header: "Salle" },
          ]}
        />
      )}

      {tab === "niveaux" && (
        <CrudPage
          title=""
          apiResource={niveauxApi}
          filters={{ etablissement: etablissementId }}
          fields={[
            { name: "nom", label: "Nom (ex: 6e, Terminale, CP1)", required: true },
            {
              name: "cycle", label: "Cycle", type: "select", required: true,
              options: [
                { value: "prescolaire", label: "Préscolaire" },
                { value: "primaire", label: "Primaire" },
                { value: "secondaire_1", label: "Secondaire 1er cycle" },
                { value: "secondaire_2", label: "Secondaire 2nd cycle" },
              ],
            },
            { name: "ordre", label: "Ordre d'affichage", type: "number" },
          ]}
        />
      )}

      {tab === "matieres" && (
        <CrudPage
          title=""
          apiResource={matieresApi}
          filters={{ etablissement: etablissementId }}
          fields={[
            { name: "nom", label: "Nom de la matière", required: true },
            { name: "code", label: "Code" },
            { name: "coefficient_defaut", label: "Coefficient par défaut", type: "number" },
          ]}
        />
      )}
    </div>
  );
}
