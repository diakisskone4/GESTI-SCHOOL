import CrudPage from "../../components/ui/CrudPage";
import { etablissementsApi } from "../../api/endpoints";

export default function EtablissementsPage() {
  return (
    <CrudPage
      title="Établissements"
      subtitle="Gestion multi-établissements"
      apiResource={etablissementsApi}
      fields={[
        { name: "nom", label: "Nom", required: true },
        { name: "sigle", label: "Sigle", required: true },
        {
          name: "type_etablissement", label: "Type", type: "select",
          options: [
            { value: "prescolaire", label: "Préscolaire" },
            { value: "primaire", label: "Primaire" },
            { value: "secondaire", label: "Secondaire" },
            { value: "mixte", label: "Mixte" },
          ],
        },
        { name: "ville", label: "Ville" },
        { name: "adresse", label: "Adresse" },
        { name: "telephone", label: "Téléphone" },
        { name: "email", label: "Email", type: "email" },
        { name: "actif", label: "Établissement actif", type: "checkbox" },
      ]}
      columns={[
        { key: "nom", header: "Nom" },
        { key: "sigle", header: "Sigle" },
        { key: "ville", header: "Ville" },
        {
          key: "actif", header: "Statut",
          render: (r) => (
            <span className={`badge ${r.actif ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"}`}>
              {r.actif ? "Actif" : "Inactif"}
            </span>
          ),
        },
      ]}
    />
  );
}
