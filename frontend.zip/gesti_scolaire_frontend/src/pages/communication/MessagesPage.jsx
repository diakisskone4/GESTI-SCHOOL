import { useState } from "react";
import { Send } from "lucide-react";
import PageHeader from "../../components/ui/PageHeader";
import Modal from "../../components/ui/Modal";
import { useFetch } from "../../hooks/useFetch";
import { useAuth } from "../../context/AuthContext";
import { useToast, extractErrorMessage } from "../../context/ToastContext";
import { messagesApi, usersApi } from "../../api/endpoints";

export default function MessagesPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const { data, loading, reload } = useFetch(() => messagesApi.list(), []);
  const { data: users } = useFetch(() => (user?.est_admin ? usersApi.list() : Promise.resolve(null)), [user]);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ destinataire: "", objet: "", contenu: "" });
  const [saving, setSaving] = useState(false);

  const handleSend = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await messagesApi.create(form);
      notify("Message envoyé.", "success");
      setModalOpen(false);
      setForm({ destinataire: "", objet: "", contenu: "" });
      reload();
    } catch (err) {
      notify(extractErrorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  };

  const messages = data?.results || [];

  return (
    <div>
      <PageHeader
        title="Messagerie interne"
        subtitle="Échanges entre administration, enseignants, élèves et parents"
        actions={
          <button onClick={() => setModalOpen(true)} className="btn-primary">
            <Send size={16} /> Nouveau message
          </button>
        }
      />

      <div className="space-y-3">
        {loading && <p className="text-sm text-slate-400">Chargement...</p>}
        {!loading && messages.length === 0 && (
          <div className="card p-8 text-center text-sm text-slate-400">Aucun message pour le moment.</div>
        )}
        {messages.map((m) => {
          const sentByMe = m.expediteur === user?.id;
          return (
            <div key={m.id} className={`card p-4 ${!m.lu && !sentByMe ? "ring-1 ring-brand-200" : ""}`}>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>{sentByMe ? `À : ${m.destinataire_nom}` : `De : ${m.expediteur_nom}`}</span>
                <span>{new Date(m.created_at).toLocaleString("fr-FR")}</span>
              </div>
              {m.objet && <p className="mt-1.5 text-sm font-semibold text-slate-700">{m.objet}</p>}
              <p className="mt-1 text-sm text-slate-600">{m.contenu}</p>
            </div>
          );
        })}
      </div>

      <Modal
        open={modalOpen} onClose={() => setModalOpen(false)} title="Nouveau message"
        footer={<>
          <button className="btn-secondary" onClick={() => setModalOpen(false)}>Annuler</button>
          <button className="btn-primary" disabled={saving} form="msg-form">Envoyer</button>
        </>}
      >
        <form id="msg-form" onSubmit={handleSend} className="space-y-4">
          <div>
            <label className="label">Destinataire</label>
            {users ? (
              <select required className="input" value={form.destinataire} onChange={(e) => setForm({ ...form, destinataire: e.target.value })}>
                <option value="">Sélectionner...</option>
                {users.results?.filter((u) => u.id !== user.id).map((u) => (
                  <option key={u.id} value={u.id}>{u.full_name} ({u.role})</option>
                ))}
              </select>
            ) : (
              <input required className="input" placeholder="ID du destinataire" value={form.destinataire} onChange={(e) => setForm({ ...form, destinataire: e.target.value })} />
            )}
          </div>
          <div>
            <label className="label">Objet</label>
            <input className="input" value={form.objet} onChange={(e) => setForm({ ...form, objet: e.target.value })} />
          </div>
          <div>
            <label className="label">Message</label>
            <textarea required rows={4} className="input" value={form.contenu} onChange={(e) => setForm({ ...form, contenu: e.target.value })} />
          </div>
        </form>
      </Modal>
    </div>
  );
}
