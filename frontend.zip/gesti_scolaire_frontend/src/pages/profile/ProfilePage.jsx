import { useState } from "react";
import PageHeader from "../../components/ui/PageHeader";
import { useAuth, ROLE_LABELS } from "../../context/AuthContext";
import { useToast, extractErrorMessage } from "../../context/ToastContext";
import { authApi } from "../../api/endpoints";

export default function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const { notify } = useToast();
  const [form, setForm] = useState({ first_name: user?.first_name, last_name: user?.last_name, telephone: user?.telephone || "" });
  const [saving, setSaving] = useState(false);

  const [pwdForm, setPwdForm] = useState({ ancien_mot_de_passe: "", nouveau_mot_de_passe: "" });
  const [pwdSaving, setPwdSaving] = useState(false);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await authApi.updateMe(form);
      await refreshUser();
      notify("Profil mis à jour.", "success");
    } catch (err) {
      notify(extractErrorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  };

  const handlePwd = async (e) => {
    e.preventDefault();
    setPwdSaving(true);
    try {
      await authApi.changePassword(pwdForm);
      notify("Mot de passe changé.", "success");
      setPwdForm({ ancien_mot_de_passe: "", nouveau_mot_de_passe: "" });
    } catch (err) {
      notify(extractErrorMessage(err), "error");
    } finally {
      setPwdSaving(false);
    }
  };

  return (
    <div className="max-w-2xl">
      <PageHeader title="Mon profil" subtitle={ROLE_LABELS[user?.role]} />

      <form onSubmit={handleSave} className="card mb-6 space-y-4 p-6">
        <p className="text-sm font-semibold text-slate-700">Informations personnelles</p>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label">Prénom</label>
            <input className="input" value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
          </div>
          <div>
            <label className="label">Nom</label>
            <input className="input" value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
          </div>
        </div>
        <div>
          <label className="label">Téléphone</label>
          <input className="input" value={form.telephone} onChange={(e) => setForm({ ...form, telephone: e.target.value })} />
        </div>
        <div>
          <label className="label">Email</label>
          <input disabled className="input opacity-60" value={user?.email} />
        </div>
        <button className="btn-primary" disabled={saving}>Enregistrer</button>
      </form>

      <form onSubmit={handlePwd} className="card space-y-4 p-6">
        <p className="text-sm font-semibold text-slate-700">Changer le mot de passe</p>
        <div>
          <label className="label">Mot de passe actuel</label>
          <input required type="password" className="input" value={pwdForm.ancien_mot_de_passe} onChange={(e) => setPwdForm({ ...pwdForm, ancien_mot_de_passe: e.target.value })} />
        </div>
        <div>
          <label className="label">Nouveau mot de passe</label>
          <input required type="password" className="input" value={pwdForm.nouveau_mot_de_passe} onChange={(e) => setPwdForm({ ...pwdForm, nouveau_mot_de_passe: e.target.value })} />
        </div>
        <button className="btn-primary" disabled={pwdSaving}>Changer le mot de passe</button>
      </form>
    </div>
  );
}
