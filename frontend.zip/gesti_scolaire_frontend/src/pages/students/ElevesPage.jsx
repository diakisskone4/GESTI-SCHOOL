import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus } from "lucide-react";
import PageHeader from "../../components/ui/PageHeader";
import DataTable from "../../components/ui/DataTable";
import Modal from "../../components/ui/Modal";
import { useFetch } from "../../hooks/useFetch";
import { useAuth } from "../../context/AuthContext";
import { useToast, extractErrorMessage } from "../../context/ToastContext";
import { elevesApi, classesApi, anneesScolairesApi, inscriptionsApi } from "../../api/endpoints";

const EMPTY_FORM = {
  nom: "", prenom: "", sexe: "M", date_naissance: "", lieu_naissance: "",
  classe: "", annee_scolaire: "",
};

export default function ElevesPage() {
  const { user } = useAuth();
  const { notify } = useToast();
  const navigate = useNavigate();
  const etablissementId = user?.etablissement_courant;

  const [search, setSearch] = useState("");
  const { data, loading, reload } = useFetch(
    () => elevesApi.list({ etablissement: etablissementId, search }),
    [etablissementId, search]
  );
  const { data: classes } = useFetch(() => classesApi.list({ etablissement: etablissementId }), [etablissementId]);
  const { data: annees } = useFetch(() => anneesScolairesApi.list({ etablissement: etablissementId }), [etablissementId]);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const openCreate = () => {
    const anneeCourante = annees?.results?.find((a) => a.est_courante);
    setForm({ ...EMPTY_FORM, annee_scolaire: anneeCourante?.id || "" });
    setModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { classe, annee_scolaire, ...eleveData } = form;
      const eleve = await elevesApi.create({ ...eleveData, etablissement: etablissementId });
      if (classe && annee_scolaire) {
        await inscriptionsApi.create({ eleve: eleve.id, classe, annee_scolaire });
      }
      notify("Élève inscrit avec succès.", "success");
      setModalOpen(false);
      reload();
    } catch (err) {
      notify(extractErrorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Élèves"
        subtitle="Inscriptions, profils et historique scolaire"
        actions={
          <button onClick={openCreate} className="btn-primary">
            <Plus size={16} /> Inscrire un élève
          </button>
        }
      />

      <div className="mb-4">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher par nom, prénom ou matricule..."
          className="input max-w-sm"
        />
      </div>

      <DataTable
        loading={loading}
        rows={data?.results || []}
        onRowClick={(row) => navigate(`/eleves/${row.id}`)}
        columns={[
          { key: "matricule", header: "Matricule" },
          { key: "nom_complet", header: "Nom complet" },
          { key: "sexe", header: "Sexe" },
          { key: "classe_actuelle", header: "Classe", render: (r) => r.classe_actuelle || "—" },
          {
            key: "actif", header: "Statut",
            render: (r) => (
              <span className={`badge ${r.actif ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"}`}>
                {r.actif ? "Actif" : "Inactif"}
              </span>
            ),
          },
        ]}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Inscrire un nouvel élève"
        width="max-w-2xl"
        footer={
          <>
            <button className="btn-secondary" onClick={() => setModalOpen(false)}>Annuler</button>
            <button className="btn-primary" disabled={saving} form="eleve-form">Enregistrer</button>
          </>
        }
      >
        <form id="eleve-form" onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="label">Nom</label>
            <input required className="input" value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} />
          </div>
          <div>
            <label className="label">Prénom</label>
            <input required className="input" value={form.prenom} onChange={(e) => setForm({ ...form, prenom: e.target.value })} />
          </div>
          <div>
            <label className="label">Sexe</label>
            <select className="input" value={form.sexe} onChange={(e) => setForm({ ...form, sexe: e.target.value })}>
              <option value="M">Masculin</option>
              <option value="F">Féminin</option>
            </select>
          </div>
          <div>
            <label className="label">Date de naissance</label>
            <input required type="date" className="input" value={form.date_naissance} onChange={(e) => setForm({ ...form, date_naissance: e.target.value })} />
          </div>
          <div className="sm:col-span-2">
            <label className="label">Lieu de naissance</label>
            <input className="input" value={form.lieu_naissance} onChange={(e) => setForm({ ...form, lieu_naissance: e.target.value })} />
          </div>
          <div>
            <label className="label">Classe</label>
            <select className="input" value={form.classe} onChange={(e) => setForm({ ...form, classe: e.target.value })}>
              <option value="">— Sans classe pour l'instant —</option>
              {(classes?.results || []).map((c) => (
                <option key={c.id} value={c.id}>{c.nom}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Année scolaire</label>
            <select className="input" value={form.annee_scolaire} onChange={(e) => setForm({ ...form, annee_scolaire: e.target.value })}>
              <option value="">—</option>
              {(annees?.results || []).map((a) => (
                <option key={a.id} value={a.id}>{a.libelle}</option>
              ))}
            </select>
          </div>
        </form>
      </Modal>
    </div>
  );
}
