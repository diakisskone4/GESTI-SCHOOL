import PageHeader from "../../components/ui/PageHeader";
import DataTable from "../../components/ui/DataTable";
import { useFetch } from "../../hooks/useFetch";
import { cartesScolairesApi } from "../../api/endpoints";
import { downloadAuthFile } from "../../utils/download";
import { Download } from "lucide-react";

export default function CartesScolairesPage() {
  const { data, loading } = useFetch(() => cartesScolairesApi.list(), []);

  return (
    <div>
      <PageHeader
        title="Cartes scolaires"
        subtitle="Cartes générées au format A6 (104×148mm) — la génération se fait depuis la fiche de chaque élève"
      />
      <DataTable
        loading={loading}
        rows={data?.results || []}
        columns={[
          { key: "numero_carte", header: "Numéro" },
          { key: "eleve_nom", header: "Élève" },
          { key: "date_emission", header: "Date d'émission" },
          {
            key: "pdf", header: "",
            render: (r) => (
              <button
                onClick={() => downloadAuthFile(cartesScolairesApi.pdfPath(r.id), `${r.numero_carte}.pdf`)}
                className="flex items-center gap-1.5 text-sm font-semibold text-brand-600 hover:underline"
              >
                <Download size={14} /> Télécharger
              </button>
            ),
          },
        ]}
      />
    </div>
  );
}
