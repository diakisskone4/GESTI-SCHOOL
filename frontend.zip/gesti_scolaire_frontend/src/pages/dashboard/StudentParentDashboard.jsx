import { useEffect, useState } from "react";
import { Award, BookOpenCheck, IdCard, MessageSquareWarning } from "lucide-react";
import PageHeader from "../../components/ui/PageHeader";
import StatCard from "../../components/ui/StatCard";
import DataTable from "../../components/ui/DataTable";
import { useAuth } from "../../context/AuthContext";
import { elevesApi, bulletinsApi } from "../../api/endpoints";
import api from "../../api/client";
import { downloadAuthFile } from "../../utils/download";

export default function StudentParentDashboard() {
  const { user } = useAuth();
  const [eleve, setEleve] = useState(null);
  const [historique, setHistorique] = useState(null);
  const [bulletins, setBulletins] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        let cibleEleve = null;
        if (user.role === "eleve") {
          const res = await elevesApi.list({ user: user.id });
          cibleEleve = res.results?.[0];
        } else if (user.role === "parent") {
          const { data } = await api.get("/liens-parent-eleve/mes_enfants/");
          if (data?.[0]) {
            cibleEleve = await elevesApi.get(data[0].eleve);
          }
        }
        if (cibleEleve) {
          setEleve(cibleEleve);
          const hist = await elevesApi.historique(cibleEleve.id);
          setHistorique(hist);
        }
        const bul = await bulletinsApi.list();
        setBulletins(bul.results || []);
      } finally {
        setLoading(false);
      }
    })();
  }, [user]);

  const dernier = historique?.parcours?.[0];

  return (
    <div>
      <PageHeader
        title={`Bonjour, ${user?.first_name} 👋`}
        subtitle={eleve ? `Suivi de ${eleve.prenom} ${eleve.nom}` : "Votre portail scolaire"}
      />

      {!loading && !eleve && (
        <div className="card p-6 text-sm text-slate-500">
          Aucun profil élève n'est encore lié à ce compte. Contactez l'administration de votre établissement.
        </div>
      )}

      {eleve && (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard icon={IdCard} tone="brand" label="Classe actuelle" value={eleve.classe_actuelle || "—"} />
            <StatCard icon={BookOpenCheck} tone="sky" label="Absences" value={dernier?.nb_absences ?? 0} />
            <StatCard icon={MessageSquareWarning} tone="amber" label="Retards" value={dernier?.nb_retards ?? 0} />
            <StatCard icon={Award} tone="emerald" label="Récompenses" value={dernier?.recompenses ?? 0} />
          </div>

          <div className="mt-6">
            <p className="mb-3 text-sm font-semibold text-slate-700">Mes bulletins</p>
            <DataTable
              loading={loading}
              rows={bulletins}
              columns={[
                { key: "periode", header: "Période", render: (r) => r.periode_libelle || `Période #${r.periode}` },
                { key: "moyenne_generale", header: "Moyenne générale", render: (r) => r.moyenne_generale ?? "—" },
                { key: "rang", header: "Rang", render: (r) => (r.rang ? `${r.rang}/${r.effectif_classe}` : "—") },
                { key: "mention", header: "Mention" },
                {
                  key: "pdf",
                  header: "",
                  render: (r) => (
                    <button
                      onClick={() => downloadAuthFile(bulletinsApi.pdfPath(r.id), `bulletin_${r.id}.pdf`)}
                      className="text-sm font-semibold text-brand-600 hover:underline"
                    >
                      Télécharger PDF
                    </button>
                  ),
                },
              ]}
            />
          </div>
        </>
      )}
    </div>
  );
}
