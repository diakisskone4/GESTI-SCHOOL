import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { GraduationCap, Loader2, Lock, Mail } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { extractErrorMessage } from "../../context/ToastContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      const dest = location.state?.from?.pathname || "/";
      navigate(dest, { replace: true });
    } catch (err) {
      setError(extractErrorMessage(err) || "Identifiants invalides.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-600 text-white shadow-lg shadow-brand-600/30">
            <GraduationCap size={28} />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">Gesti-Scolaire</h1>
          <p className="mt-1 text-sm text-slate-500">Connectez-vous à votre espace ERP</p>
        </div>

        <form onSubmit={handleSubmit} className="card p-6 sm:p-8">
          {error && (
            <div className="mb-4 rounded-xl bg-rose-50 px-3.5 py-2.5 text-sm text-rose-600">{error}</div>
          )}

          <label className="label" htmlFor="email">Adresse email</label>
          <div className="relative mb-4">
            <Mail size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="vous@etablissement.ml"
              className="input pl-10"
            />
          </div>

          <label className="label" htmlFor="password">Mot de passe</label>
          <div className="relative mb-6">
            <Lock size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="input pl-10"
            />
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading && <Loader2 size={16} className="animate-spin" />}
            Se connecter
          </button>

          <p className="mt-5 text-center text-xs text-slate-400">
            Compte de démonstration : admin@gesti-scolaire.local / Admin@1234
          </p>
        </form>
      </div>
    </div>
  );
}
