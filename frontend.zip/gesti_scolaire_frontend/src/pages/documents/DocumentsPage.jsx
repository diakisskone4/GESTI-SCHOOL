import { useState } from "react";
import { Download, Plus } from "lucide-react";
import PageHeader from "../../components/ui/PageHeader";
import DataTable from "../../components/ui/DataTable";
import Modal from "../../components/ui/Modal";
import { useFetch } from "../../hooks/useFetch";
import { useToast, extractErrorMessage } from "../../context/ToastContext";
import { documentsGeneresApi, elevesApi } from "../../api/endpoints";
import { downloadAuthFile } from "../../utils/download";

const TYPES = [
  { value: "certificat_scolarite", label: "Certificat de scolarité" },
  { value: "certificat_frequentation", label: "Certificat de fréquentation" },
  { value: "convocation_examen", label: "Convocation - Examen" },
  { value: "convocation_reunion", label: "Convocation - Réunion" },
  { value: "attestation_reussite", label: "Attestation de réussite" },
  { value: "attestation_passage", label: "Attestation de passage" },
];

export default function DocumentsPage() {
  const { notify } = useToast();
  const { data, loading, reload } = useFetch(() => documentsGeneresApi.list(), []);
  const { data: eleves } = useFetch(() => elevesApi.list(), []);

  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ type_document: "", eleve: "", objet: "", date_evenement: "", lieu_evenement: "" });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const doc = await documentsGeneresApi.create(form);
      notify("Document créé, génération du PDF...", "success");
      await downloadAuthFile(documentsGeneresApi.pdfPath(doc.id), `${doc.reference}.pdf`);
      setModalOpen(false);
      reload();
    } catch (err) {
      notify(extractErrorMessage(err), "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Documents administratifs"
        subtitle="Certificats, convocations et attestations"
        actions={
          <button onClick={() => { setForm({ type_document: "", eleve: "", objet: "", date_evenement: "", lieu_evenement: "" }); setModalOpen(true); }} className="btn-primary">
            <Plus size={16} /> Générer un document
          </button>
        }
      />

      <DataTable
        loading={loading}
        rows={data?.results || []}
        columns={[
          { key: "reference", header: "Référence" },
          { key: "type_document", header: "Type" },
          { key: "eleve_nom", header: "Élève", render: (r) => r.eleve_nom || "—" },
          { key: "created_at", header: "Créé le", render: (r) => new Date(r.created_at).toLocaleDateString("fr-FR") },
          {
            key: "pdf", header: "",
            render: (r) => (
              <button
                onClick={() => downloadAuthFile(documentsGeneresApi.pdfPath(r.id), `${r.reference}.pdf`)}
                className="flex items-center gap-1.5 text-sm font-semibold text-brand-600 hover:underline"
              >
                <Download size={14} /> PDF
              </button>
            ),
          },
        ]}
      />

      <Modal
        open={modalOpen} onClose={() => setModalOpen(false)} title="Générer un document"
        footer={<>
          <button className="btn-secondary" onClick={() => setModalOpen(false)}>Annuler</button>
          <button className="btn-primary" disabled={saving} form="doc-form">Générer</button>
        </>}
      >
        <form id="doc-form" onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Type de document</label>
            <select required className="input" value={form.type_document} onChange={(e) => setForm({ ...form, type_document: e.target.value })}>
              <option value="">Sélectionner...</option>
              {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Élève concerné</label>
            <select className="input" value={form.eleve} onChange={(e) => setForm({ ...form, eleve: e.target.value })}>
              <option value="">—</option>
              {(eleves?.results || []).map((el) => <option key={el.id} value={el.id}>{el.nom_complet}</option>)}
            </select>
          </div>
          {form.type_document.startsWith("convocation") && (
            <>
              <div>
                <label className="label">Date de l'événement</label>
                <input type="date" className="input" value={form.date_evenement} onChange={(e) => setForm({ ...form, date_evenement: e.target.value })} />
              </div>
              <div>
                <label className="label">Lieu</label>
                <input className="input" value={form.lieu_evenement} onChange={(e) => setForm({ ...form, lieu_evenement: e.target.value })} />
              </div>
            </>
          )}
          <div>
            <label className="label">Objet / précisions (optionnel)</label>
            <textarea className="input" rows={3} value={form.objet} onChange={(e) => setForm({ ...form, objet: e.target.value })} />
          </div>
        </form>
      </Modal>
    </div>
  );
}
