import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { ToastProvider } from "./context/ToastContext";
import ProtectedRoute from "./routes/ProtectedRoute";
import DashboardLayout from "./components/layout/DashboardLayout";

import Login from "./pages/auth/Login";
import DashboardRouter from "./pages/dashboard/DashboardRouter";
import EtablissementsPage from "./pages/core/EtablissementsPage";
import ClassesPage from "./pages/core/ClassesPage";
import ElevesPage from "./pages/students/ElevesPage";
import EleveDetailPage from "./pages/students/EleveDetailPage";
import AbsencesPage from "./pages/students/AbsencesPage";
import CartesScolairesPage from "./pages/students/CartesScolairesPage";
import EnseignantsPage from "./pages/staff/EnseignantsPage";
import BulletinsPage from "./pages/academics/BulletinsPage";
import DocumentsPage from "./pages/documents/DocumentsPage";
import FacturesPage from "./pages/finance/FacturesPage";
import PaiePage from "./pages/payroll/PaiePage";
import MessagesPage from "./pages/communication/MessagesPage";
import AnnoncesPage from "./pages/communication/AnnoncesPage";
import StatistiquesPage from "./pages/reporting/StatistiquesPage";
import ProfilePage from "./pages/profile/ProfilePage";

const ADMIN_ROLES = ["admin", "superadmin"];
const FINANCE_ROLES = ["admin", "superadmin", "comptable"];
const ACADEMIC_ROLES = ["admin", "superadmin", "enseignant"];

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            <Route path="/connexion" element={<Login />} />

            <Route element={<ProtectedRoute />}>
              <Route element={<DashboardLayout />}>
                <Route path="/" element={<DashboardRouter />} />
                <Route path="/profil" element={<ProfilePage />} />
                <Route path="/messages" element={<MessagesPage />} />
                <Route path="/annonces" element={<AnnoncesPage />} />

                <Route element={<ProtectedRoute roles={ADMIN_ROLES} />}>
                  <Route path="/etablissements" element={<EtablissementsPage />} />
                  <Route path="/classes" element={<ClassesPage />} />
                  <Route path="/eleves" element={<ElevesPage />} />
                  <Route path="/eleves/:id" element={<EleveDetailPage />} />
                  <Route path="/enseignants" element={<EnseignantsPage />} />
                  <Route path="/cartes-scolaires" element={<CartesScolairesPage />} />
                  <Route path="/documents" element={<DocumentsPage />} />
                  <Route path="/statistiques" element={<StatistiquesPage />} />
                </Route>

                <Route element={<ProtectedRoute roles={ACADEMIC_ROLES} />}>
                  <Route path="/academique/bulletins" element={<BulletinsPage />} />
                  <Route path="/absences" element={<AbsencesPage />} />
                </Route>

                <Route element={<ProtectedRoute roles={FINANCE_ROLES} />}>
                  <Route path="/finance/factures" element={<FacturesPage />} />
                  <Route path="/paie" element={<PaiePage />} />
                </Route>
              </Route>
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
