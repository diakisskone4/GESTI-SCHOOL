from django.core.files.base import ContentFile
from django.db.models import Sum
from django.http import FileResponse
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.core.pdf_utils import generer_recu_paiement_pdf
from apps.core.permissions import IsAdmin
from apps.finance.models import BaremeFrais, Bourse, FactureFrais, Paiement, TypeFrais
from apps.finance.serializers import (
    BaremeFraisSerializer,
    BourseSerializer,
    FactureFraisSerializer,
    PaiementSerializer,
    TypeFraisSerializer,
)


class TypeFraisViewSet(viewsets.ModelViewSet):
    queryset = TypeFrais.objects.all()
    serializer_class = TypeFraisSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["etablissement", "periodicite", "obligatoire"]


class BaremeFraisViewSet(viewsets.ModelViewSet):
    queryset = BaremeFrais.objects.select_related("type_frais", "niveau", "annee_scolaire")
    serializer_class = BaremeFraisSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["type_frais", "niveau", "annee_scolaire"]


class BourseViewSet(viewsets.ModelViewSet):
    queryset = Bourse.objects.select_related("inscription__eleve")
    serializer_class = BourseSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["inscription", "type_bourse", "actif"]

    def perform_create(self, serializer):
        serializer.save(approuve_par=self.request.user)


class FactureFraisViewSet(viewsets.ModelViewSet):
    queryset = FactureFrais.objects.select_related("inscription__eleve", "type_frais", "periode").prefetch_related("paiements")
    serializer_class = FactureFraisSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["inscription", "type_frais", "periode", "statut"]
    search_fields = ["inscription__eleve__nom", "inscription__eleve__prenom", "inscription__eleve__matricule"]


class PaiementViewSet(viewsets.ModelViewSet):
    queryset = Paiement.objects.select_related("facture__inscription__eleve")
    serializer_class = PaiementSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["facture", "mode_paiement", "annule", "date_paiement"]

    def perform_create(self, serializer):
        serializer.save(encaisse_par=self.request.user)

    @action(detail=True, methods=["get"])
    def recu(self, request, pk=None):
        """Génère et renvoie le reçu de paiement imprimable (PDF A5)."""
        paiement = self.get_object()
        etablissement = paiement.facture.inscription.eleve.etablissement
        buffer = generer_recu_paiement_pdf(paiement, etablissement)
        paiement.recu_pdf.save(f"recu_{paiement.numero_recu}.pdf", ContentFile(buffer.getvalue()), save=True)
        buffer.seek(0)
        return FileResponse(buffer, as_attachment=False, filename=f"recu_{paiement.numero_recu}.pdf", content_type="application/pdf")


class DashboardFinancierView(viewsets.ViewSet):
    """Tableau de bord financier : totaux facturés, encaissés, impayés."""
    permission_classes = [IsAdmin]

    def list(self, request):
        etablissement_id = request.query_params.get("etablissement")
        annee_id = request.query_params.get("annee_scolaire")
        factures = FactureFrais.objects.all()
        if etablissement_id:
            factures = factures.filter(inscription__eleve__etablissement_id=etablissement_id)
        if annee_id:
            factures = factures.filter(inscription__annee_scolaire_id=annee_id)

        total_facture = factures.aggregate(t=Sum("montant_du"))["t"] or 0
        total_remise = factures.aggregate(t=Sum("montant_remise"))["t"] or 0
        total_encaisse = Paiement.objects.filter(facture__in=factures, annule=False).aggregate(t=Sum("montant"))["t"] or 0
        total_du = float(total_facture) - float(total_remise)
        total_impaye = total_du - float(total_encaisse)

        par_statut = {}
        for statut, _ in FactureFrais.STATUT_CHOICES:
            par_statut[statut] = factures.filter(statut=statut).count()

        return Response({
            "total_facture": float(total_facture),
            "total_remise": float(total_remise),
            "total_encaisse": float(total_encaisse),
            "total_impaye": max(total_impaye, 0),
            "nb_factures": factures.count(),
            "repartition_par_statut": par_statut,
        })
