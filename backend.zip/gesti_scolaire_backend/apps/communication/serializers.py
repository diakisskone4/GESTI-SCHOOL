from rest_framework import serializers

from apps.communication.models import Annonce, Message, Notification


class MessageSerializer(serializers.ModelSerializer):
    expediteur_nom = serializers.CharField(source="expediteur.get_full_name", read_only=True)
    destinataire_nom = serializers.CharField(source="destinataire.get_full_name", read_only=True)

    class Meta:
        model = Message
        fields = "__all__"
        read_only_fields = ["id", "expediteur", "lu", "lu_le"]


class AnnonceSerializer(serializers.ModelSerializer):
    auteur_nom = serializers.CharField(source="auteur.get_full_name", read_only=True)

    class Meta:
        model = Annonce
        fields = "__all__"
        read_only_fields = ["id", "auteur", "date_publication"]


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = "__all__"
        read_only_fields = ["statut", "envoyee_le", "erreur"]
