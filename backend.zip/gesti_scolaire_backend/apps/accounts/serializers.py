from django.contrib.auth import password_validation
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from apps.accounts.models import LienParentEleve, User


class UserSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(source="get_full_name", read_only=True)

    class Meta:
        model = User
        fields = [
            "id", "email", "first_name", "last_name", "full_name", "role",
            "telephone", "photo", "etablissements", "etablissement_courant",
            "langue_preferee", "is_active", "date_joined", "date_derniere_activite",
        ]
        read_only_fields = ["id", "date_joined", "date_derniere_activite"]


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    password_confirm = serializers.CharField(write_only=True, min_length=8)

    class Meta:
        model = User
        fields = [
            "email", "first_name", "last_name", "password", "password_confirm",
            "role", "telephone", "etablissement_courant",
        ]

    def validate(self, attrs):
        if attrs["password"] != attrs.pop("password_confirm"):
            raise serializers.ValidationError({"password_confirm": "Les mots de passe ne correspondent pas."})
        password_validation.validate_password(attrs["password"])
        # Seul un admin peut créer un autre admin ; l'auto-inscription publique
        # est restreinte aux rôles élève/parent par la vue (voir accounts/views.py).
        return attrs

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        if user.etablissement_courant:
            user.etablissements.add(user.etablissement_courant)
        return user


class ChangePasswordSerializer(serializers.Serializer):
    ancien_mot_de_passe = serializers.CharField(write_only=True)
    nouveau_mot_de_passe = serializers.CharField(write_only=True, min_length=8)

    def validate_nouveau_mot_de_passe(self, value):
        password_validation.validate_password(value, self.context["request"].user)
        return value


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """Ajoute le rôle et l'établissement courant dans le payload du token JWT."""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["role"] = user.role
        token["email"] = user.email
        token["full_name"] = user.get_full_name()
        token["etablissement_id"] = str(user.etablissement_courant_id) if user.etablissement_courant_id else None
        return token

    def validate(self, attrs):
        data = super().validate(attrs)
        data["user"] = UserSerializer(self.user).data
        return data


class LienParentEleveSerializer(serializers.ModelSerializer):
    class Meta:
        model = LienParentEleve
        fields = ["id", "parent", "eleve", "relation", "est_contact_principal"]
