from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from apps.core.models import (
    AnneeScolaire,
    Classe,
    CreneauEmploiDuTemps,
    Etablissement,
    JournalActivite,
    Matiere,
    Niveau,
    Periode,
    Serie,
)
from apps.core.permissions import IsAdmin, IsAdminOrReadOnly
from apps.core.serializers import (
    AnneeScolaireSerializer,
    ClasseSerializer,
    CreneauEmploiDuTempsSerializer,
    EtablissementSerializer,
    JournalActiviteSerializer,
    MatiereSerializer,
    NiveauSerializer,
    PeriodeSerializer,
    SerieSerializer,
)


class EtablissementViewSet(viewsets.ModelViewSet):
    queryset = Etablissement.objects.all()
    serializer_class = EtablissementSerializer
    permission_classes = [IsAdminOrReadOnly]
    search_fields = ["nom", "sigle", "ville"]
    filterset_fields = ["actif", "type_etablissement"]


class AnneeScolaireViewSet(viewsets.ModelViewSet):
    queryset = AnneeScolaire.objects.all()
    serializer_class = AnneeScolaireSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["etablissement", "est_courante"]


class PeriodeViewSet(viewsets.ModelViewSet):
    queryset = Periode.objects.all()
    serializer_class = PeriodeSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["annee_scolaire", "est_courante", "type_periode", "cloturee"]


class NiveauViewSet(viewsets.ModelViewSet):
    queryset = Niveau.objects.all()
    serializer_class = NiveauSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["etablissement", "cycle"]


class SerieViewSet(viewsets.ModelViewSet):
    queryset = Serie.objects.all()
    serializer_class = SerieSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["niveau"]


class ClasseViewSet(viewsets.ModelViewSet):
    queryset = Classe.objects.select_related("niveau", "serie", "annee_scolaire", "professeur_principal")
    serializer_class = ClasseSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["etablissement", "annee_scolaire", "niveau", "serie"]
    search_fields = ["nom"]


class MatiereViewSet(viewsets.ModelViewSet):
    queryset = Matiere.objects.all()
    serializer_class = MatiereSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["etablissement"]
    search_fields = ["nom", "code"]


class CreneauEmploiDuTempsViewSet(viewsets.ModelViewSet):
    queryset = CreneauEmploiDuTemps.objects.select_related("classe", "matiere", "enseignant")
    serializer_class = CreneauEmploiDuTempsSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["classe", "matiere", "enseignant", "jour"]


class JournalActiviteViewSet(viewsets.ReadOnlyModelViewSet):
    """Consultation du journal d'audit (lecture seule, admin uniquement)."""
    queryset = JournalActivite.objects.select_related("utilisateur", "etablissement")
    serializer_class = JournalActiviteSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["action", "utilisateur", "etablissement"]
    search_fields = ["description", "modele"]
