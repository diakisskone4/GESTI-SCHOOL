from rest_framework import serializers

from apps.core.models import (
    AnneeScolaire,
    Classe,
    CreneauEmploiDuTemps,
    Etablissement,
    JournalActivite,
    Matiere,
    Niveau,
    Periode,
    Serie,
)


class EtablissementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Etablissement
        fields = "__all__"


class AnneeScolaireSerializer(serializers.ModelSerializer):
    class Meta:
        model = AnneeScolaire
        fields = "__all__"


class PeriodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Periode
        fields = "__all__"


class NiveauSerializer(serializers.ModelSerializer):
    class Meta:
        model = Niveau
        fields = "__all__"


class SerieSerializer(serializers.ModelSerializer):
    class Meta:
        model = Serie
        fields = "__all__"


class ClasseSerializer(serializers.ModelSerializer):
    effectif_actuel = serializers.IntegerField(read_only=True)
    niveau_nom = serializers.CharField(source="niveau.nom", read_only=True)

    class Meta:
        model = Classe
        fields = "__all__"


class MatiereSerializer(serializers.ModelSerializer):
    class Meta:
        model = Matiere
        fields = "__all__"


class CreneauEmploiDuTempsSerializer(serializers.ModelSerializer):
    matiere_nom = serializers.CharField(source="matiere.nom", read_only=True)
    enseignant_nom = serializers.CharField(source="enseignant.__str__", read_only=True)

    class Meta:
        model = CreneauEmploiDuTemps
        fields = "__all__"


class JournalActiviteSerializer(serializers.ModelSerializer):
    utilisateur_nom = serializers.CharField(source="utilisateur.get_full_name", read_only=True)

    class Meta:
        model = JournalActivite
        fields = "__all__"
        read_only_fields = fields
