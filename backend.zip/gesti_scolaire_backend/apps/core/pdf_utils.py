"""Génération de documents PDF (cartes scolaires, bulletins, reçus, attestations...).

Utilise ReportLab. Toutes les fonctions renvoient un buffer BytesIO prêt
à être servi via HttpResponse ou sauvegardé dans un FileField.
"""
import io
import qrcode
from reportlab.lib.pagesizes import A5, A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

# Format carte scolaire A6 : 104 x 148 mm (portrait)
CARTE_SIZE = (104 * mm, 148 * mm)


def generer_carte_scolaire_pdf(eleve, inscription, etablissement, qr_data=""):
    """Génère une carte scolaire au format A6 (104x148mm) avec photo, identité, année scolaire."""
    buffer = io.BytesIO()
    largeur, hauteur = CARTE_SIZE
    c = canvas.Canvas(buffer, pagesize=CARTE_SIZE)

    # Bordure
    c.setStrokeColor(colors.HexColor("#1a4d8f"))
    c.setLineWidth(2)
    c.rect(3 * mm, 3 * mm, largeur - 6 * mm, hauteur - 6 * mm)

    # En-tête établissement
    c.setFillColor(colors.HexColor("#1a4d8f"))
    c.rect(3 * mm, hauteur - 20 * mm, largeur - 6 * mm, 17 * mm, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 8)
    c.drawCentredString(largeur / 2, hauteur - 9 * mm, etablissement.nom[:35])
    c.setFont("Helvetica", 6)
    c.drawCentredString(largeur / 2, hauteur - 13 * mm, "CARTE SCOLAIRE")
    c.drawCentredString(largeur / 2, hauteur - 17 * mm, inscription.annee_scolaire.libelle)

    # Photo
    photo_x, photo_y, photo_w, photo_h = 6 * mm, hauteur - 55 * mm, 28 * mm, 32 * mm
    c.setStrokeColor(colors.grey)
    c.rect(photo_x, photo_y, photo_w, photo_h)
    if eleve.photo:
        try:
            img = ImageReader(eleve.photo.path)
            c.drawImage(img, photo_x, photo_y, width=photo_w, height=photo_h, preserveAspectRatio=True, anchor="c")
        except Exception:
            pass

    # Identité
    text_x = 38 * mm
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(text_x, hauteur - 26 * mm, f"{eleve.nom.upper()}")
    c.setFont("Helvetica", 8)
    c.drawString(text_x, hauteur - 31 * mm, f"{eleve.prenom}")
    c.setFont("Helvetica", 6.5)
    c.drawString(text_x, hauteur - 38 * mm, f"Matricule: {eleve.matricule}")
    c.drawString(text_x, hauteur - 43 * mm, f"Né(e) le: {eleve.date_naissance:%d/%m/%Y}" if eleve.date_naissance else "")
    c.drawString(text_x, hauteur - 48 * mm, f"Classe: {inscription.classe.nom}")
    c.drawString(text_x, hauteur - 53 * mm, f"Sexe: {eleve.get_sexe_display()}")

    # QR code
    qr_img = qrcode.make(qr_data or str(eleve.id))
    qr_buffer = io.BytesIO()
    qr_img.save(qr_buffer, format="PNG")
    qr_buffer.seek(0)
    qr_size = 20 * mm
    c.drawImage(ImageReader(qr_buffer), largeur - qr_size - 6 * mm, 8 * mm, width=qr_size, height=qr_size)

    # Pied de page
    c.setFont("Helvetica-Oblique", 5.5)
    c.drawString(6 * mm, 5 * mm, "En cas de perte, contacter l'établissement")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def generer_bulletin_pdf(eleve, inscription, periode, lignes_notes, moyenne_generale, rang, effectif_classe, etablissement, appreciation=""):
    """Génère un bulletin scolaire au format A5.

    lignes_notes: liste de dicts {matiere, moyenne, coefficient, moyenne_ponderee, rang_matiere, appreciation}
    """
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A5)
    largeur, hauteur = A5

    marge = 10 * mm
    y = hauteur - marge

    # En-tête
    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(largeur / 2, y, etablissement.nom)
    y -= 5 * mm
    c.setFont("Helvetica", 8)
    c.drawCentredString(largeur / 2, y, f"{etablissement.adresse} - {etablissement.telephone}")
    y -= 7 * mm
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(largeur / 2, y, f"BULLETIN DE NOTES - {periode.libelle}")
    y -= 4 * mm
    c.setFont("Helvetica", 9)
    c.drawCentredString(largeur / 2, y, f"Année scolaire {inscription.annee_scolaire.libelle}")
    y -= 8 * mm

    # Identité élève
    c.setFont("Helvetica", 9)
    c.drawString(marge, y, f"Élève: {eleve.prenom} {eleve.nom}")
    c.drawRightString(largeur - marge, y, f"Matricule: {eleve.matricule}")
    y -= 5 * mm
    c.drawString(marge, y, f"Classe: {inscription.classe.nom}")
    c.drawRightString(largeur - marge, y, f"Effectif: {effectif_classe}")
    y -= 8 * mm

    # Tableau des notes
    col_matiere = marge
    col_moy = largeur - marge - 90 * mm + 55 * mm
    col_coef = largeur - marge - 40 * mm
    col_rang = largeur - marge - 20 * mm

    c.setFont("Helvetica-Bold", 8)
    c.drawString(col_matiere, y, "Matière")
    c.drawString(col_moy, y, "Moyenne")
    c.drawString(col_coef, y, "Coef.")
    c.drawString(col_rang, y, "Rang")
    y -= 3 * mm
    c.line(marge, y, largeur - marge, y)
    y -= 5 * mm

    c.setFont("Helvetica", 8)
    for ligne in lignes_notes:
        if y < 30 * mm:
            c.showPage()
            y = hauteur - marge
        c.drawString(col_matiere, y, str(ligne.get("matiere", ""))[:28])
        c.drawString(col_moy, y, f"{ligne.get('moyenne', ''):.2f}" if ligne.get("moyenne") is not None else "-")
        c.drawString(col_coef, y, str(ligne.get("coefficient", "")))
        c.drawString(col_rang, y, str(ligne.get("rang_matiere", "-")))
        y -= 5 * mm

    y -= 3 * mm
    c.line(marge, y, largeur - marge, y)
    y -= 7 * mm

    c.setFont("Helvetica-Bold", 10)
    c.drawString(marge, y, f"Moyenne générale: {moyenne_generale:.2f}/20")
    c.drawRightString(largeur - marge, y, f"Rang: {rang}/{effectif_classe}")
    y -= 8 * mm

    if appreciation:
        c.setFont("Helvetica-Oblique", 8)
        c.drawString(marge, y, f"Appréciation du conseil: {appreciation}")
        y -= 10 * mm

    y -= 10 * mm
    c.setFont("Helvetica", 8)
    c.drawString(marge, y, "Le Directeur")
    if etablissement.directeur_signature:
        try:
            c.drawImage(ImageReader(etablissement.directeur_signature.path), marge, y - 18 * mm, width=25 * mm, height=15 * mm, preserveAspectRatio=True)
        except Exception:
            pass

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def generer_document_administratif_pdf(titre, etablissement, contenu_lignes, destinataire="", reference=""):
    """Génère un document administratif générique en A4 :
    certificat de scolarité, attestation, convocation, etc."""
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    largeur, hauteur = A4
    marge = 20 * mm
    y = hauteur - marge

    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(largeur / 2, y, etablissement.nom)
    y -= 6 * mm
    c.setFont("Helvetica", 9)
    c.drawCentredString(largeur / 2, y, f"{etablissement.adresse} - Tél: {etablissement.telephone}")
    y -= 15 * mm

    if reference:
        c.setFont("Helvetica", 9)
        c.drawString(marge, y, f"Réf: {reference}")
        y -= 10 * mm

    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(largeur / 2, y, titre.upper())
    y -= 20 * mm

    c.setFont("Helvetica", 11)
    for ligne in contenu_lignes:
        for sous_ligne in _wrap_text(ligne, 90):
            c.drawString(marge, y, sous_ligne)
            y -= 7 * mm
        y -= 3 * mm

    y -= 20 * mm
    c.setFont("Helvetica", 10)
    from datetime import date
    c.drawRightString(largeur - marge, y, f"Fait le {date.today():%d/%m/%Y}")
    y -= 20 * mm
    c.drawRightString(largeur - marge, y, "Le Directeur")
    if etablissement.directeur_signature:
        try:
            c.drawImage(ImageReader(etablissement.directeur_signature.path), largeur - marge - 30 * mm, y - 20 * mm, width=30 * mm, height=18 * mm, preserveAspectRatio=True)
        except Exception:
            pass

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def generer_recu_paiement_pdf(recu, etablissement):
    """Génère un reçu de paiement imprimable (A5)."""
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A5)
    largeur, hauteur = A5
    marge = 10 * mm
    y = hauteur - marge

    c.setFont("Helvetica-Bold", 12)
    c.drawCentredString(largeur / 2, y, etablissement.nom)
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 13)
    c.drawCentredString(largeur / 2, y, "REÇU DE PAIEMENT")
    y -= 10 * mm

    c.setFont("Helvetica", 9)
    c.drawString(marge, y, f"N° Reçu: {recu.numero_recu}")
    c.drawRightString(largeur - marge, y, f"Date: {recu.date_paiement:%d/%m/%Y}")
    y -= 7 * mm
    c.drawString(marge, y, f"Élève: {recu.eleve.prenom} {recu.eleve.nom}")
    y -= 6 * mm
    c.drawString(marge, y, f"Matricule: {recu.eleve.matricule}")
    y -= 10 * mm
    c.setFont("Helvetica-Bold", 10)
    c.drawString(marge, y, f"Motif: {recu.libelle}")
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 12)
    c.drawString(marge, y, f"Montant payé: {recu.montant:,.0f} FCFA")
    y -= 6 * mm
    c.setFont("Helvetica", 9)
    c.drawString(marge, y, f"Mode de paiement: {recu.get_mode_paiement_display()}")
    y -= 15 * mm
    c.drawRightString(largeur - marge, y, "Signature du caissier")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def generer_bulletin_paie_pdf(bulletin, etablissement):
    """Génère le bulletin de paie PDF (A4) d'un employé pour un mois donné."""
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    largeur, hauteur = A4
    marge = 20 * mm
    y = hauteur - marge

    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(largeur / 2, y, etablissement.nom)
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 13)
    c.drawCentredString(largeur / 2, y, f"BULLETIN DE PAIE - {bulletin.mois:02d}/{bulletin.annee}")
    y -= 12 * mm

    employe = bulletin.employe
    c.setFont("Helvetica", 10)
    c.drawString(marge, y, f"Employé: {employe.prenom} {employe.nom}")
    c.drawRightString(largeur - marge, y, f"Matricule: {employe.matricule}")
    y -= 6 * mm
    c.drawString(marge, y, f"Fonction: {employe.get_type_employe_display()}")
    y -= 10 * mm

    c.line(marge, y, largeur - marge, y)
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 10)
    c.drawString(marge, y, "Désignation")
    c.drawRightString(largeur - marge, y, "Montant (FCFA)")
    y -= 5 * mm
    c.line(marge, y, largeur - marge, y)
    y -= 7 * mm

    c.setFont("Helvetica", 10)
    lignes = [
        ("Salaire de base", bulletin.salaire_base),
        ("Total primes", bulletin.total_primes),
        ("Total indemnités", bulletin.total_indemnites),
        ("Heures supplémentaires", bulletin.total_heures_sup),
    ]
    for lib, montant in lignes:
        c.drawString(marge, y, lib)
        c.drawRightString(largeur - marge, y, f"{montant:,.0f}")
        y -= 6 * mm

    y -= 3 * mm
    c.setFont("Helvetica-Bold", 10)
    c.drawString(marge, y, "Salaire brut")
    c.drawRightString(largeur - marge, y, f"{bulletin.salaire_brut:,.0f}")
    y -= 8 * mm

    c.setFont("Helvetica", 10)
    for lib, montant in [("Retenues", bulletin.total_retenues), ("Avances déduites", bulletin.avances_deduites)]:
        c.drawString(marge, y, f"- {lib}")
        c.drawRightString(largeur - marge, y, f"{montant:,.0f}")
        y -= 6 * mm

    y -= 6 * mm
    c.line(marge, y, largeur - marge, y)
    y -= 8 * mm
    c.setFont("Helvetica-Bold", 13)
    c.drawString(marge, y, "NET À PAYER")
    c.drawRightString(largeur - marge, y, f"{bulletin.net_a_payer:,.0f} FCFA")

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer


def _wrap_text(text, max_chars):
    import textwrap
    return textwrap.wrap(text, max_chars) or [""]
