from rest_framework import serializers

from apps.documents_mgmt.models import DocumentGenere


class DocumentGenereSerializer(serializers.ModelSerializer):
    eleve_nom = serializers.CharField(source="eleve.__str__", read_only=True)
    employe_nom = serializers.CharField(source="employe.__str__", read_only=True)

    class Meta:
        model = DocumentGenere
        fields = "__all__"
        read_only_fields = ["id", "reference", "fichier_pdf", "genere_par"]
