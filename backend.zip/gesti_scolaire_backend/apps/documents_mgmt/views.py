from django.core.files.base import ContentFile
from django.http import FileResponse
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.core.pdf_utils import generer_document_administratif_pdf
from apps.core.permissions import IsAdmin
from apps.documents_mgmt.models import DocumentGenere
from apps.documents_mgmt.serializers import DocumentGenereSerializer

TITRES = {
    "certificat_scolarite": "Certificat de scolarité",
    "certificat_frequentation": "Certificat de fréquentation scolaire",
    "convocation_examen": "Convocation à un examen",
    "convocation_reunion": "Convocation à une réunion",
    "attestation_reussite": "Attestation de réussite",
    "attestation_passage": "Attestation de passage",
}


class DocumentGenereViewSet(viewsets.ModelViewSet):
    queryset = DocumentGenere.objects.select_related("eleve", "employe", "inscription")
    serializer_class = DocumentGenereSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["type_document", "eleve", "employe"]
    search_fields = ["reference", "objet"]

    def perform_create(self, serializer):
        serializer.save(genere_par=self.request.user)

    @action(detail=True, methods=["get"])
    def pdf(self, request, pk=None):
        """Génère le PDF du document (A4) à partir de son contenu texte et l'archive."""
        doc = self.get_object()
        titre = TITRES.get(doc.type_document, doc.get_type_document_display())
        etablissement = (doc.eleve.etablissement if doc.eleve else None) or (doc.employe.etablissement if doc.employe else None)
        lignes = self._construire_contenu(doc)
        buffer = generer_document_administratif_pdf(
            titre=titre, etablissement=etablissement, contenu_lignes=lignes,
            destinataire=str(doc.eleve or doc.employe or ""), reference=doc.reference,
        )
        doc.fichier_pdf.save(f"{doc.reference}.pdf", ContentFile(buffer.getvalue()), save=True)
        buffer.seek(0)
        return FileResponse(buffer, as_attachment=False, filename=f"{doc.reference}.pdf", content_type="application/pdf")

    def _construire_contenu(self, doc):
        if doc.contenu_texte:
            return doc.contenu_texte.split("\n")
        eleve = doc.eleve
        if doc.type_document in ("certificat_scolarite", "certificat_frequentation") and eleve:
            insc = eleve.inscription_courante
            return [
                f"Je soussigné, Directeur de l'établissement, certifie que l'élève {eleve.prenom} {eleve.nom}, "
                f"né(e) le {eleve.date_naissance:%d/%m/%Y} à {eleve.lieu_naissance or '...'},",
                f"est régulièrement inscrit(e) dans notre établissement en classe de {insc.classe.nom if insc else '...'} "
                f"pour l'année scolaire {insc.annee_scolaire.libelle if insc else '...'}.",
                "En foi de quoi ce certificat lui est délivré pour servir et valoir ce que de droit.",
            ]
        if doc.type_document.startswith("convocation"):
            lieu = doc.lieu_evenement or "l'établissement"
            return [
                f"Nous vous prions de bien vouloir vous présenter le {doc.date_evenement:%d/%m/%Y}" if doc.date_evenement else "Nous vous prions de bien vouloir vous présenter",
                f"à {lieu} concernant : {doc.objet}.",
                "Votre présence est indispensable.",
            ]
        if doc.type_document.startswith("attestation") and eleve:
            insc = eleve.inscription_courante
            return [
                f"Nous attestons que {eleve.prenom} {eleve.nom} a suivi avec succès sa scolarité "
                f"en classe de {insc.classe.nom if insc else '...'}.",
                doc.objet or "",
            ]
        return [doc.objet or ""]
