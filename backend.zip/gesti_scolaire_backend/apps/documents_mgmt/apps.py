from django.apps import AppConfig


class DocumentsMgmtConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.documents_mgmt"
