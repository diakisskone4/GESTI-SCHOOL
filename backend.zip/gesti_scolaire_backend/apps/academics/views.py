import io
import openpyxl
from django.http import FileResponse, HttpResponse
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.academics.models import Bulletin, Examen, MoyenneMatiere, Note, TableauHonneur, TypeEvaluation
from apps.academics.serializers import (
    BulletinSerializer,
    ExamenSerializer,
    MoyenneMatiereSerializer,
    NoteSerializer,
    TableauHonneurSerializer,
    TypeEvaluationSerializer,
)
from apps.academics.services import (
    calculer_moyenne_generale_et_rangs,
    calculer_moyennes_matiere,
    generer_pdf_bulletin,
)
from apps.core.models import Classe, Periode
from apps.core.permissions import IsAdmin, IsAdminOrEnseignantReadWrite


class TypeEvaluationViewSet(viewsets.ModelViewSet):
    queryset = TypeEvaluation.objects.all()
    serializer_class = TypeEvaluationSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["etablissement"]


class NoteViewSet(viewsets.ModelViewSet):
    queryset = Note.objects.select_related("inscription__eleve", "matiere", "periode")
    serializer_class = NoteSerializer
    permission_classes = [IsAdminOrEnseignantReadWrite]
    filterset_fields = ["inscription", "matiere", "periode", "type_evaluation", "enseignant"]
    search_fields = ["inscription__eleve__nom", "inscription__eleve__prenom"]

    def perform_create(self, serializer):
        from apps.staff.models import Enseignant
        enseignant = Enseignant.objects.filter(user=self.request.user).first()
        serializer.save(enseignant=enseignant or serializer.validated_data.get("enseignant"))


class MoyenneMatiereViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = MoyenneMatiere.objects.select_related("inscription__eleve", "matiere", "periode")
    serializer_class = MoyenneMatiereSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["inscription", "matiere", "periode"]


class BulletinViewSet(viewsets.ModelViewSet):
    """Bulletins. Admin/enseignant : tout. Élève/parent : uniquement les bulletins
    de leur(s) propre(s) enfant(s) (accès restreint côté requête)."""
    serializer_class = BulletinSerializer
    filterset_fields = ["inscription", "periode", "valide"]

    def get_queryset(self):
        qs = Bulletin.objects.select_related("inscription__eleve", "inscription__classe", "periode")
        user = self.request.user
        if user.est_admin or user.est_enseignant:
            return qs
        if user.est_eleve:
            return qs.filter(inscription__eleve__user=user)
        if user.est_parent:
            return qs.filter(inscription__eleve__parents_lies__parent=user)
        return qs.none()

    def get_permissions(self):
        if self.action in ("create", "update", "partial_update", "destroy", "calculer"):
            return [IsAdmin()]
        return [IsAuthenticated()]

    @action(detail=False, methods=["post"])
    def calculer(self, request):
        """Calcule moyennes matières, moyenne générale et rangs pour une classe/période."""
        classe = Classe.objects.get(pk=request.data.get("classe"))
        periode = Periode.objects.get(pk=request.data.get("periode"))
        calculer_moyennes_matiere(classe, periode)
        bulletins = calculer_moyenne_generale_et_rangs(classe, periode)
        return Response({
            "detail": f"{len(bulletins)} bulletins calculés pour {classe.nom} - {periode.libelle}.",
            "bulletins": BulletinSerializer(bulletins, many=True).data,
        })

    @action(detail=True, methods=["get"])
    def pdf(self, request, pk=None):
        """Génère et renvoie le PDF du bulletin (format A5)."""
        bulletin = self.get_object()
        generer_pdf_bulletin(bulletin)
        bulletin.refresh_from_db()
        return FileResponse(bulletin.fichier_pdf.open("rb"), as_attachment=False,
                             filename=bulletin.fichier_pdf.name.split("/")[-1], content_type="application/pdf")


class TableauHonneurViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = TableauHonneur.objects.select_related("inscription__eleve", "inscription__classe", "periode")
    serializer_class = TableauHonneurSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["periode", "niveau", "inscription__classe"]


class ExamenViewSet(viewsets.ModelViewSet):
    queryset = Examen.objects.select_related("classe", "matiere", "periode").prefetch_related("surveillants")
    serializer_class = ExamenSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["etablissement", "classe", "matiere", "periode", "statut", "date_examen"]


class ExportResultatsView(viewsets.ViewSet):
    """Export des résultats d'une classe/période en PDF ou Excel."""
    permission_classes = [IsAdmin]

    @action(detail=False, methods=["get"])
    def excel(self, request):
        classe_id = request.query_params.get("classe")
        periode_id = request.query_params.get("periode")
        bulletins = Bulletin.objects.filter(inscription__classe_id=classe_id, periode_id=periode_id).select_related(
            "inscription__eleve"
        ).order_by("rang")

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Résultats"
        ws.append(["Rang", "Matricule", "Nom", "Prénom", "Moyenne Générale", "Mention"])
        for b in bulletins:
            ws.append([b.rang, b.inscription.eleve.matricule, b.inscription.eleve.nom,
                       b.inscription.eleve.prenom, float(b.moyenne_generale or 0), b.mention])

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)
        response = HttpResponse(
            buffer.getvalue(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = "attachment; filename=resultats.xlsx"
        return response
