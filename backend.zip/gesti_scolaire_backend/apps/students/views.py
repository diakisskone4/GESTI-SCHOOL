from django.core.files.base import ContentFile
from django.http import FileResponse
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.core.pdf_utils import generer_carte_scolaire_pdf
from apps.core.permissions import IsAdmin, IsAdminOrReadOnly
from apps.students.models import Absence, CarteScolaire, Eleve, Inscription, SanctionRecompense
from apps.students.serializers import (
    AbsenceSerializer,
    CarteScolaireSerializer,
    EleveSerializer,
    InscriptionSerializer,
    SanctionRecompenseSerializer,
)


class EleveViewSet(viewsets.ModelViewSet):
    queryset = Eleve.objects.select_related("etablissement", "user")
    serializer_class = EleveSerializer
    permission_classes = [IsAdminOrReadOnly]
    filterset_fields = ["etablissement", "sexe", "actif", "user"]
    search_fields = ["nom", "prenom", "matricule"]

    @action(detail=True, methods=["get"], permission_classes=[IsAuthenticated])
    def historique(self, request, pk=None):
        """Historique scolaire complet : inscriptions, absences, sanctions/récompenses."""
        eleve = self.get_object()
        inscriptions = eleve.inscriptions.select_related("classe", "annee_scolaire").order_by("-date_inscription")
        data = []
        for insc in inscriptions:
            data.append({
                "annee_scolaire": insc.annee_scolaire.libelle,
                "classe": insc.classe.nom,
                "statut": insc.get_statut_display(),
                "redoublant": insc.redoublant,
                "nb_absences": insc.absences.filter(type_evenement="absence").count(),
                "nb_retards": insc.absences.filter(type_evenement="retard").count(),
                "sanctions": insc.sanctions_recompenses.filter(nature="sanction").count(),
                "recompenses": insc.sanctions_recompenses.filter(nature="recompense").count(),
            })
        return Response({"eleve": EleveSerializer(eleve).data, "parcours": data})


class InscriptionViewSet(viewsets.ModelViewSet):
    queryset = Inscription.objects.select_related("eleve", "classe", "annee_scolaire")
    serializer_class = InscriptionSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["classe", "annee_scolaire", "statut", "type_inscription", "boursier", "redoublant"]
    search_fields = ["eleve__nom", "eleve__prenom", "eleve__matricule"]


class AbsenceViewSet(viewsets.ModelViewSet):
    queryset = Absence.objects.select_related("inscription__eleve")
    serializer_class = AbsenceSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["inscription", "type_evenement", "justifiee", "date"]

    def perform_create(self, serializer):
        serializer.save(signale_par=self.request.user)


class SanctionRecompenseViewSet(viewsets.ModelViewSet):
    queryset = SanctionRecompense.objects.select_related("inscription__eleve")
    serializer_class = SanctionRecompenseSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["inscription", "nature", "periode"]

    def perform_create(self, serializer):
        serializer.save(decidee_par=self.request.user)


class CarteScolaireViewSet(viewsets.ModelViewSet):
    queryset = CarteScolaire.objects.select_related("inscription__eleve", "inscription__classe")
    serializer_class = CarteScolaireSerializer
    permission_classes = [IsAdmin]
    filterset_fields = ["inscription"]

    @action(detail=True, methods=["get"])
    def pdf(self, request, pk=None):
        """Génère (ou régénère) et retourne le PDF de la carte scolaire au format A6."""
        carte = self.get_object()
        inscription = carte.inscription
        eleve = inscription.eleve
        buffer = generer_carte_scolaire_pdf(eleve, inscription, eleve.etablissement, qr_data=carte.qr_code_data)
        carte.fichier_pdf.save(f"carte_{eleve.matricule}.pdf", ContentFile(buffer.getvalue()), save=True)
        buffer.seek(0)
        return FileResponse(buffer, as_attachment=False, filename=f"carte_{eleve.matricule}.pdf", content_type="application/pdf")

    @action(detail=False, methods=["post"])
    def generer_pour_inscription(self, request):
        """Crée (si besoin) et génère la carte scolaire pour une inscription donnée."""
        inscription_id = request.data.get("inscription")
        try:
            inscription = Inscription.objects.select_related("eleve", "classe").get(pk=inscription_id)
        except Inscription.DoesNotExist:
            return Response({"detail": "Inscription introuvable."}, status=404)
        carte, _ = CarteScolaire.objects.get_or_create(inscription=inscription)
        return Response(CarteScolaireSerializer(carte).data, status=201)
